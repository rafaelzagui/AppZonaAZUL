package br.com.puccampinas.fiscalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.appcompat.widget.AppCompatButton
import androidx.appcompat.widget.AppCompatEditText
import androidx.appcompat.widget.AppCompatTextView
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var etPlaca:AppCompatEditText
    private lateinit var btnConsultar:AppCompatButton
    private lateinit var tvStatus:AppCompatTextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etPlaca = findViewById(R.id.etPlaca)
        btnConsultar = findViewById(R.id.btnConsultar)
        btnConsultar.setOnClickListener{
        VerificaPlaca()
        }
        tvStatus = findViewById(R.id.tvStatus)
    }

    private fun VerificaPlaca()
    {
     //caso o usuario não digite nada da placa exibir um erro
        if(etPlaca.text.isNullOrEmpty())
        {
        Snackbar.make(tvStatus,"Informe a Placa do veiculo Para consultar o status",Snackbar.LENGTH_LONG).show()
            val message="A placa: ${etPlaca} está devendo"
            tvStatus.text = message
            tvStatus.visibility = View.VISIBLE
            etPlaca.text!!.clear()
        }

    }
}